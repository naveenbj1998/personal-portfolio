import React from "react";
import './Intro.css';
import Github from '../../img/github.png';
import LinledIn from '../../img/linkedin.png';
import Instagram from '../../img/instagram.png';
import Vector1 from '../../img/Vector1.png';
import Vector2 from '../../img/Vector2.png';
import boy from '../../img/boy.png';
import thumbup from '../../img/thumbup.png';
import Crown from '../../img/crown.png';
import glassesimoji from '../../img/glassesimoji.png';
import FloatingDiv from "../FloatingDiv/FloatingDiv";
import _Resume from '../programming/_Resume.pdf';
import { themeContext } from "../../Context";
import { useContext } from "react";
import { motion } from "framer-motion";
const Intro =()=>{
    const transition = {duration:2,type:'spring'};
    const theme = useContext(themeContext);
    const darkMode = theme.state.darkMode;
    return(
        <div className="intro">
            <div className="i-left">
                <div className="i-name">
                    <span style={{color:darkMode?'white':""}}>Hi! I am</span>
                    <span>Naveen Babu</span>
                    <span>I am a interactive web developer</span>
                </div>
                <a href={_Resume} download><button className="button i-button">Download CV</button></a>
                <div className="i-icons">
                    <img src={Github} alt="github"></img>
                    <img src={LinledIn} alt="linkedin"></img>
                    <img src={Instagram} alt="instagram"></img>
                </div>
            </div>
            <div className="i-right">
                    <img src={Vector1} alt=""></img>
                    <img src={Vector2} alt=""></img>
                    <img src={boy} alt=""></img>
                    <motion.img initial={{left:'-36%'}} whileInView={{left:'-24%'}} transition={transition} src={glassesimoji} alt=""></motion.img>
                    <div style={{top:'-4%',left:'65%'}}>
                        <FloatingDiv image={Crown} txt1='Web' txt2='Developer'></FloatingDiv>
                    </div>
                    <div style={{top:'23rem',left:'2rem'}}>
                        <FloatingDiv image={thumbup} txt1='Interactive' txt2='Design'></FloatingDiv>
                    </div>
                    <div className="blur" style={{background:"rgb(238 210 255)"}}></div>
                    <div className="blur" style={{background:'#C1F5FF',top:'17rem',width:'21rem',height:'11rem',left:'-9rem'}}></div>
            </div>
        </div>
    )
}

export default Intro;