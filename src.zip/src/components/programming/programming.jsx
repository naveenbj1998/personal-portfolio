import React from "react";
import './programming.css';
import HeartEmoji from '../../img/heartemoji.png';
import Glasses from '../../img/glasses.png';
import Humble from '../../img/humble.png';
import ss from '../../img/ss.png';
import ss1 from '../../img/ss1.png';
import Card from "../Card/Card";
import _Resume from './_Resume.pdf'
const Programming=()=>{
    return(
        <div className="programming">
            <div className="awesome">
                <span>Programming</span>
                <span>Languages</span>
                <span>These are all the programming languages <br></br>i know.</span>
                <a href={_Resume} download><button className="button p-button">Download CV</button></a>
                <div className="blur p-blur1" style={{background:'#ABF1FF94'}}></div>
            </div>
            <div className="cards">
                <div className="p-img p-img1"><img src={ss}></img></div>
                <div className="p-img p-img2"><img src={ss}></img></div>
                <div style={{left:'34rem'}}><Card emoji={HeartEmoji} heading={'Languages'} detail={"HTML5/CSS3 JavaScript"}></Card></div>
                <div style={{top:'12rem', left:'12rem'}}><Card emoji={Glasses} heading={'Frameworks'} detail={"CSS Bootstrap React.js"}></Card></div>
                <div style={{top:'19rem',left:'30rem'}}><Card emoji={Humble} heading={'others'} detail={"vfydbivbv"}></Card></div>
                <div className="blur p-blur2" style={{background:'var(--purple)'}}></div>
                <div className="blur p-blur3" style={{background:'#ABF1FF94'}}></div>
            </div>
        </div>
    )
}

export default Programming;