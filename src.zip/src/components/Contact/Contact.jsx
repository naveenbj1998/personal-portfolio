import React from "react";
import emailjs from '@emailjs/browser';
import './Contact.css';
import { useRef } from "react";
const Contact = ()=>{
    const form = useRef();

    const sendEmail = (e) => {
      e.preventDefault();
  
      emailjs.sendForm('service_0c23csp', 'template_9dqa1i1', form.current, 'Ym0cIglNDMcdsPvbsH')
        .then((result) => {
            console.log(result.text);
        }, (error) => {
            console.log(error.text);
        });
    };
    return(
        <div className="contact-form">
            <div className="w-left">
                <div className="awesome">
                    <span>Get in touch</span>
                    <span>Contact me</span>
                    <div className="blur p-blur1" style={{background:'#ABF1FF94'}}></div>
                </div>
            </div>
            <div className="c-right">
                <form ref={form} onSubmit={sendEmail}>
                    <input type="text" name="user_name"className="user"placeholder="Name"/>
                    <input type="email" name="user_email"className="user"placeholder="Email"/>
                    <textarea name="message" className="user" placeholder="message"></textarea>
                    <input type="submit" value="Send" className="button"></input>
                    <div className="blur c-blur1" style={{background:'var(--purple)'}}></div>
                </form>
            </div>
        </div>
    )
}
export default Contact;